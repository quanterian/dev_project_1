#! /bin/bash

cd /var/www/html 

php bin/magento setup:upgrade

php bin/magento cache:clean

php bin/magento setup:static-content:deploy -f

chmod -R 777 *
