#! /bin/bash

cd /var/www/html/magento2-2.3.5-p1

chmod -R 777 *

php bin/magento setup:upgrade

php bin/magento cache:clean

php bin/magento setup:static-content:deploy -f

chmod -R 777 *
